﻿using System;

namespace Spaccamiglio.Luca._4h.MatriceAzteca
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            MatriceAzteca matriceAzteca = new MatriceAzteca();//instanzia matrice

            matriceAzteca.CreateArray();

            Console.WriteLine();

            var m = matriceAzteca.CreateArray();
            for (var c = 0; c < 10; c++)
            {
                for (var j = 0; j < 10; j++)
                Console.Write(m[c, j] + " ");//stampa finale
                Console.WriteLine();
            }
        }
    }

    public class MatriceAzteca
    {
        public MatriceAzteca()//costruttore
        {
        }
        public int[,] CreateArray()
        {
            var m = new int[10, 10];
            for (var c = 1; c <= 10; c++)
                for (var j = 1; j <= 10; j++)
                {
                    m[c - 1, j - 1] = Math.Min(c > 5 ? 11 - c : c, j > 5 ? 11 - j : j);
                }
            return m;//ritorna il valore di m
        }
    }
}
	